import { useEffect, useMemo, useState } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ComposedChart,
  Legend,
  Line,
  LineChart,
  ReferenceLine,
  ResponsiveContainer,
  Scatter,
  ScatterChart,
  Tooltip,
  XAxis,
  YAxis,
  ZAxis,
} from "recharts";

const DATA_FILES = {
  framingYear: "framing_scores_by_year.json",
  framingDecade: "framing_scores_by_decade.json",
  cooccurrenceYear: "economic_security_cooccurrence_by_year.json",
  cooccurrenceDecade: "economic_security_cooccurrence_by_decade.json",
  semanticPairs: "semantic_similarity_pairs_by_decade.json",
  keywords: "top_keywords_by_decade.json",
  articles: "representative_articles_for_close_reading.json",
  events: "historical_events.json",
  sectionFraming: "section_framing_by_decade.json",
  newsDeskFraming: "news_desk_framing_by_decade.json",
  balanceSummary: "balanced_sampling_summary.json",
  topWords: "top_40_words_by_decade.json",
  themeFraming: "theme_framing_by_decade.json",
  network: "cooccurrence_network.json",
  wordNetwork: "word_cooccurrence_network_by_decade.json",
  references: "references.json",
};

const DECADES = ["1990s", "2000s", "2010s", "2020s"];
const FRAME_OPTIONS = [
  { key: "opportunity_score", label: "Opportunity", color: "#2b8a67" },
  { key: "threat_score", label: "Threat", color: "#b84949" },
  { key: "competition_score", label: "Competition", color: "#8a5b23" },
  { key: "cooperation_score", label: "Engagement", color: "#3b6ea8" },
];
const PAIR_OPTIONS = [
  "trade/security",
  "technology/security",
  "china/competition",
  "market/security",
  "china/trade",
];
const SECTION_COLORS = ["#dae8f2", "#b7d4e5", "#8dbbd3", "#5d9ab8", "#2f748f"];

function formatNumber(value, digits = 2) {
  if (value === null || value === undefined || Number.isNaN(Number(value))) return "n/a";
  return Number(value).toFixed(digits);
}

function readableLabel(value) {
  const labels = {
    economy_trade: "Economic / Trade",
    military_security: "Military / Security",
    technology_industry: "Technology / Industry",
    public_health_covid: "Public Health / COVID",
    human_rights_values: "Human Rights / Values",
    diplomacy_engagement: "Diplomacy / Engagement",
    competition_rivalry: "Competition / Rivalry",
    territory_sovereignty: "Territory / Sovereignty",
    domestic_politics: "Domestic Politics",
  };
  return labels[value] || String(value).replaceAll("_", " ");
}

function dataUrl(file) {
  return `${import.meta.env.BASE_URL}data/${file}`;
}

async function loadJson(file) {
  const response = await fetch(dataUrl(file));
  if (!response.ok) throw new Error(`Could not load ${file}`);
  return response.json();
}

function useProjectData() {
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    Promise.all(
      Object.entries(DATA_FILES).map(async ([key, file]) => [key, await loadJson(file)])
    )
      .then((entries) => setData(Object.fromEntries(entries)))
      .catch((err) => setError(err.message));
  }, []);

  return { data, error };
}

function Card({ title, children }) {
  return (
    <aside className="card">
      <h3>{title}</h3>
      <div>{children}</div>
    </aside>
  );
}

function Explainer({ measures, read, caution }) {
  return (
    <div className="explainer">
      <h4>What this graph measures</h4>
      <p>{measures}</p>
      <h4>How to read it</h4>
      <p>{read}</p>
      <h4>What it does not prove</h4>
      <p>{caution}</p>
    </div>
  );
}

function EventMarkers({ events, y = "top" }) {
  return events.map((event) => (
    <div className={`event-marker ${y}`} key={`${event.year}-${event.event}`}>
      <span>{event.year}</span>
      <small>{event.event}</small>
    </div>
  ));
}

function ChartTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="tooltip">
      <strong>{label}</strong>
      {payload.map((item) => (
        <div key={item.dataKey} style={{ color: item.color }}>
          {item.name}: {formatNumber(item.value)}
        </div>
      ))}
    </div>
  );
}

function Landing({ balanceSummary }) {
  const target = balanceSummary?.[0]?.target_articles_per_decade;
  return (
    <section className="hero" id="about">
      <div className="hero-copy">
        <p className="eyebrow">Digital History Project</p>
        <h1>Economic Securitization in New York Times Coverage of China</h1>
        <p className="lede">
          This project studies how coverage of China from 1990 to 2025 changed over time,
          focusing on whether economic language became more connected to security,
          technology, rivalry, and competition.
        </p>
        <div className="hero-actions">
          <a href="#timeline">Explore Timeline</a>
          <a href="#method" className="secondary">Method Notes</a>
        </div>
      </div>
      <div className="hero-panel">
        <img src={`${import.meta.env.BASE_URL}assets/hero-discourse.png`} alt="Editorial collage of U.S.-China discourse, trade routes, newsprint, and semiconductor motifs" />
        <span>Balanced Corpus</span>
        <strong>{target ? `${target} clean articles per decade` : "Balanced sample"}</strong>
        <p>
          Charts use a randomly balanced corpus from quality-filtered NYT API records.
          Scores are transparent textual indicators, not objective measurements of intent.
        </p>
      </div>
    </section>
  );
}

function AboutPage() {
  return (
    <main className="page">
      <section className="section about-page">
        <div className="section-heading">
          <p className="eyebrow">About The Project</p>
          <h2>From Economic Integration To Economic Security</h2>
        </div>
        <div className="about-grid">
          <Card title="Motivation">
            <p>Structure: introduce why U.S.-China media discourse matters for understanding changing assumptions about globalization, integration, and rivalry.</p>
          </Card>
          <Card title="Main Question">
            <p>How did New York Times coverage of China from 1990 to 2025 change, and when did economic language begin appearing more often with security, technology, rivalry, and competition language?</p>
          </Card>
          <Card title="Argument">
            <p>Structure: present the argument as a shift from engagement and market opportunity toward economic securitization, using the visual evidence as indicators rather than final proof.</p>
          </Card>
          <Card title="Discussion">
            <p>Structure: compare decade-level patterns, identify years that deserve close reading, and explain where chart patterns are stable or unstable.</p>
          </Card>
          <Card title="Conclusion">
            <p>Structure: summarize what the balanced corpus shows factually, then connect it to the broader historical question about economic integration and political convergence.</p>
          </Card>
          <Card title="Further Improvement">
            <p>Ideas: add full-text articles if available, compare other newspapers, test alternative dictionaries, use multiple random balanced samples, and add manual validation of close-reading examples.</p>
          </Card>
        </div>
      </section>
    </main>
  );
}

function TimelineDashboard({ framingYear, events }) {
  const [activeFrames, setActiveFrames] = useState(FRAME_OPTIONS.map((frame) => frame.key));
  const [showEventLabels, setShowEventLabels] = useState(false);
  const visibleFrames = FRAME_OPTIONS.filter((frame) => activeFrames.includes(frame.key));
  const highlightEvents = events.filter((event) =>
    [1999, 2001, 2008, 2012, 2018, 2019, 2020, 2022, 2023].includes(Number(event.year))
  );

  function toggleFrame(key) {
    setActiveFrames((current) =>
      current.includes(key) ? current.filter((item) => item !== key) : [...current, key]
    );
  }

  return (
    <section id="timeline" className="section">
      <div className="section-heading">
        <p className="eyebrow">Timeline Dashboard</p>
        <h2>Framing Scores Over Time</h2>
      </div>
      <div className="dashboard-grid">
        <div className="chart-shell">
          <div className="toggle-row">
            {FRAME_OPTIONS.map((frame) => (
              <button
                key={frame.key}
                className={activeFrames.includes(frame.key) ? "active" : ""}
                onClick={() => toggleFrame(frame.key)}
                style={{ "--accent": frame.color }}
              >
                {frame.label}
              </button>
            ))}
            <button className={showEventLabels ? "active" : ""} onClick={() => setShowEventLabels(!showEventLabels)}>
              {showEventLabels ? "Hide event labels" : "Show event labels"}
            </button>
          </div>
          <div className="chart-wrap">
            <ResponsiveContainer width="100%" height={420}>
              <LineChart data={framingYear} margin={{ top: 16, right: 26, bottom: 8, left: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#dbe1e7" />
                <XAxis dataKey="year" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip content={<ChartTooltip />} />
                <Legend />
                {showEventLabels && highlightEvents.map((event) => (
                  <ReferenceLine
                    key={`${event.year}-${event.event}`}
                    x={Number(event.year)}
                    stroke="#d05a77"
                    strokeDasharray="4 4"
                    label={{ value: `${event.year}`, angle: -90, position: "top", fill: "#8a2944", fontSize: 11 }}
                  />
                ))}
                {visibleFrames.map((frame) => (
                  <Line
                    key={frame.key}
                    type="monotone"
                    dataKey={frame.key}
                    name={frame.label}
                    stroke={frame.color}
                    strokeWidth={1.7}
                    dot={false}
                    activeDot={{ r: 5 }}
                  />
                ))}
              </LineChart>
            </ResponsiveContainer>
            <div className="event-strip">
              <EventMarkers events={highlightEvents} />
            </div>
            {showEventLabels && (
              <div className="event-label-list">
                {highlightEvents.map((event) => (
                  <span key={`${event.year}-${event.event}`}>
                    <strong>{event.year}</strong> {event.event}
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>
        <Card title="How To Read This Quickly">
          <Explainer
            measures="The yearly average number of frame-dictionary words per 1,000 article tokens."
            read="A rising threat line means that, in that year, the sampled articles used more words from the threat dictionary. Compare two lines at a time to avoid visual overload."
            caution="It does not prove what journalists felt or intended. It only shows changes in vocabulary frequency."
          />
        </Card>
      </div>
    </section>
  );
}

function DecadeFramingComparison({ framingDecade }) {
  const data = framingDecade.map((row) => ({
    decade: row.decade,
    opportunity: row.opportunity_score,
    threat: row.threat_score,
    positive: row.positive_framing_score,
    negative: row.negative_framing_score,
  }));

  return (
    <section id="decade-framing" className="section">
      <div className="section-heading">
        <p className="eyebrow">Decade Comparison</p>
        <h2>Positive / Opportunity vs Negative / Threat Framing</h2>
      </div>
      <div className="dashboard-grid">
        <div className="chart-shell">
          <ResponsiveContainer width="100%" height={430}>
            <BarChart data={data} margin={{ top: 18, right: 24, bottom: 8, left: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#ead6df" />
              <XAxis dataKey="decade" />
              <YAxis />
              <Tooltip content={<ChartTooltip />} />
              <Legend />
              <Bar dataKey="opportunity" name="Opportunity score" fill="#2b8a67" />
              <Bar dataKey="threat" name="Threat score" fill="#d05a77" />
              <Bar dataKey="positive" name="Positive framing" fill="#77b255" />
              <Bar dataKey="negative" name="Negative framing" fill="#b2224c" />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <Card title="Why This Chart Is Here">
          <Explainer
            measures="Average dictionary-term mentions per 1,000 article tokens, grouped by decade."
            read="Bars make decade comparison easier than the yearly line chart. Positive framing combines opportunity and cooperation terms. Negative framing combines threat and competition terms."
            caution="The bars are dictionary indicators, not sentiment labels assigned by a human reader."
          />
        </Card>
      </div>
    </section>
  );
}

function Securitization({ cooccurrenceYear, cooccurrenceDecade }) {
  return (
    <section id="securitization" className="section">
      <div className="section-heading">
        <p className="eyebrow">Economic Securitization</p>
        <h2>When Economic Coverage Contains Security Language</h2>
      </div>
      <div className="dashboard-grid">
        <div className="chart-shell">
          <ResponsiveContainer width="100%" height={400}>
            <ComposedChart data={cooccurrenceYear} margin={{ top: 16, right: 24, bottom: 8, left: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#dbe1e7" />
              <XAxis dataKey="year" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip content={<ChartTooltip />} />
              <Legend />
              <Line type="monotone" dataKey="percent_with_economic_terms" name="Economic articles" stroke="#2b8a67" strokeWidth={2.5} dot={false} />
              <Line type="monotone" dataKey="percent_with_security_terms" name="Security articles" stroke="#b84949" strokeWidth={2.5} dot={false} />
              <Line type="monotone" dataKey="percent_with_both_economic_and_security" name="Economic + security overlap" stroke="#2f5f7f" strokeWidth={2.5} dot={false} />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
        <Card title="Metric Definition">
          <Explainer
            measures="The share of articles containing economic language, security language, or both in the same article."
            read="The decade cards show the overlap rate: the percent of articles in that decade that contain at least one economic term and at least one security term."
            caution="A co-occurrence does not prove the article argues that economics is security. It shows that both vocabularies appear together."
          />
          <dl className="metric-list">
            <dt>Overlap</dt>
            <dd>Percent of articles with both economic and security terms.</dd>
            <dt>Security-per-economic ratio</dt>
            <dd>Security mentions divided by economic mentions plus one.</dd>
          </dl>
        </Card>
      </div>
      <div className="mini-bars">
        {cooccurrenceDecade.map((row) => (
          <div key={row.decade} className="mini-bar">
            <span>{row.decade}</span>
            <strong>{formatNumber(row.percent_with_both_economic_and_security)}%</strong>
            <em>articles with both economic and security language</em>
            <div>
              <i style={{ width: `${Math.min(row.percent_with_both_economic_and_security * 4, 100)}%` }} />
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

function SemanticShift({ semanticPairs }) {
  const pairNames = useMemo(() => {
    const names = semanticPairs.map((row) => `${row.term_a}/${row.term_b}`);
    return Array.from(new Set(names)).filter((name) => PAIR_OPTIONS.includes(name));
  }, [semanticPairs]);
  const [selectedPairs, setSelectedPairs] = useState([
    "technology/security",
    "china/competition",
    "trade/security",
  ]);
  const chartData = DECADES.map((decade) => {
    const item = { decade };
    selectedPairs.forEach((pair) => {
      const [termA, termB] = pair.split("/");
      const found = semanticPairs.find(
        (row) => row.decade === decade && row.term_a === termA && row.term_b === termB
      );
      item[pair] = found?.similarity ?? null;
    });
    return item;
  });

  function togglePair(pair) {
    setSelectedPairs((current) =>
      current.includes(pair) ? current.filter((item) => item !== pair) : [...current, pair]
    );
  }

  return (
    <section id="semantic" className="section">
      <div className="section-heading">
        <p className="eyebrow">Semantic Shift</p>
        <h2>Embedding Similarity Across Decades</h2>
      </div>
      <div className="dashboard-grid">
        <div className="chart-shell">
          <div className="toggle-row wrap">
            {pairNames.map((pair) => (
              <button key={pair} className={selectedPairs.includes(pair) ? "active" : ""} onClick={() => togglePair(pair)}>
                {pair}
              </button>
            ))}
          </div>
          <ResponsiveContainer width="100%" height={380}>
            <LineChart data={chartData} margin={{ top: 16, right: 24, bottom: 8, left: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#dbe1e7" />
              <XAxis dataKey="decade" />
              <YAxis domain={[0, 1]} />
              <Tooltip content={<ChartTooltip />} />
              <Legend />
              {selectedPairs.map((pair, index) => (
                <Line key={pair} type="monotone" dataKey={pair} stroke={["#2f5f7f", "#b84949", "#2b8a67", "#8a5b23"][index % 4]} strokeWidth={2.5} />
              ))}
            </LineChart>
          </ResponsiveContainer>
        </div>
        <Card title="Cosine Similarity">
          <Explainer
            measures="Cosine similarity between two word vectors trained separately for each decade."
            read="A higher value means the two words appeared in more similar surrounding contexts in that decade. For example, technology/security asks whether technology words were used in contexts closer to security words."
            caution="It does not prove the words mean the same thing, and missing vocabulary is left blank rather than estimated."
          />
        </Card>
      </div>
    </section>
  );
}

function FrequencyAndThemes({ topWords, themeFraming }) {
  const [decade, setDecade] = useState("2020s");
  const wordRows = topWords.filter((row) => row.decade === decade).slice(0, 24);
  const themes = Array.from(new Set(themeFraming.map((row) => row.theme)));
  const maxPercent = Math.max(...themeFraming.map((row) => Number(row.percent_articles || 0)), 1);

  return (
    <section id="frequency" className="section">
      <div className="section-heading">
        <p className="eyebrow">Vocabulary And Themes</p>
        <h2>What Words And Frames Are Most Visible?</h2>
      </div>
      <div className="control-bar">
        <select value={decade} onChange={(event) => setDecade(event.target.value)}>
          {DECADES.map((item) => <option key={item}>{item}</option>)}
        </select>
      </div>
      <div className="wide-visual-grid">
        <div className="chart-shell tall-chart">
          <ResponsiveContainer width="100%" height={620}>
            <BarChart data={wordRows} layout="vertical" margin={{ top: 10, right: 36, bottom: 8, left: 145 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#ead6df" />
              <XAxis type="number" />
              <YAxis type="category" dataKey="word" tickFormatter={readableLabel} width={170} interval={0} tick={{ fontSize: 13 }} />
              <Tooltip content={<ChartTooltip />} />
              <Bar dataKey="per_1000_words" name="Mentions per 1,000 words" fill="#cf4d6f" />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="chart-shell theme-heatmap-shell">
          <h3>Coverage Frames by Decade</h3>
          <div className="theme-heatmap">
            <div className="theme-heatmap-header">
              <span>Theme</span>
              {DECADES.map((item) => <strong key={item}>{item}</strong>)}
            </div>
            {themes.map((theme) => (
              <div className="theme-heatmap-row" key={theme}>
                <strong>{readableLabel(theme)}</strong>
                {DECADES.map((item) => {
                  const found = themeFraming.find((row) => row.theme === theme && row.decade === item);
                  const value = Number(found?.percent_articles || 0);
                  const alpha = 0.15 + (value / maxPercent) * 0.75;
                  return (
                    <span key={item} style={{ background: `rgba(45, 115, 150, ${alpha})` }}>
                      {formatNumber(value, 0)}%
                    </span>
                  );
                })}
              </div>
            ))}
          </div>
        </div>
      </div>
      <Card title="What This Presents">
        <Explainer
          measures="The left chart shows frequent individual words. The heatmap shows the percent of articles in each decade that contain at least one term from each theme dictionary."
          read="Darker heatmap cells mean a larger share of articles in that decade touched that theme. The word bars show normalized frequency, not article share."
          caution="Theme dictionaries simplify complex language. They show where to look, not a complete interpretation."
        />
      </Card>
    </section>
  );
}

function CooccurrenceNetwork({ network }) {
  const [decade, setDecade] = useState("2020s");
  const decadeNetwork = network?.[decade] || { nodes: [], edges: [] };
  const nodes = (decadeNetwork.nodes || []).slice(0, 28);
  const visibleIds = new Set(nodes.map((node) => node.id));
  const edges = decadeNetwork.edges || [];
  const nodeMap = new Map(nodes.map((node) => [node.id, node]));
  const visibleEdges = edges
    .filter((edge) => visibleIds.has(edge.source) && visibleIds.has(edge.target))
    .sort((a, b) => b.weight - a.weight)
    .slice(0, 42);

  return (
    <section id="network" className="section">
      <div className="section-heading">
        <p className="eyebrow">Co-occurrence Network</p>
        <h2>Which Words Appear Together?</h2>
      </div>
      <div className="control-bar">
        <select value={decade} onChange={(event) => setDecade(event.target.value)}>
          {DECADES.map((item) => <option key={item}>{item}</option>)}
        </select>
      </div>
      <div className="dashboard-grid">
        <div className="network-card">
          <svg viewBox="0 0 100 100" role="img" aria-label="Word co-occurrence network">
            {visibleEdges.map((edge) => {
              const a = nodeMap.get(edge.source);
              const b = nodeMap.get(edge.target);
              if (!a || !b) return null;
              return (
                <line
                  key={`${edge.source}-${edge.target}`}
                  x1={a.x}
                  y1={a.y}
                  x2={b.x}
                  y2={b.y}
                  stroke="#b43d60"
                  strokeOpacity="0.22"
                  strokeWidth={Math.max(0.4, Math.min(4.5, edge.weight / 6))}
                />
              );
            })}
            {nodes.map((node) => {
              return (
                <g key={node.id}>
                  <circle cx={node.x} cy={node.y} r={node.size / 3.5} fill={node.color} fillOpacity="0.78" stroke="#7b1734" strokeWidth="0.35" />
                  <text x={node.x} y={node.y + node.size / 4 + 3.5} textAnchor="middle">{node.label}</text>
                </g>
              );
            })}
          </svg>
        </div>
        <Card title="How To Read The Word Network">
          <Explainer
            measures="The 28 most frequent interpretive words in the selected decade and the strongest article-level co-occurrences among them."
            read="Bigger circles are more frequent words. Thicker lines mean two words appeared in the same article more often. Colors group words by theme."
            caution="The layout is a readable map, not a statistical proof of causal relationship between words."
          />
        </Card>
      </div>
    </section>
  );
}

function FramingByMetadata({ sectionFraming, newsDeskFraming }) {
  const [mode, setMode] = useState("section");
  const [metric, setMetric] = useState("rivalry_score");
  const source = mode === "section" ? sectionFraming : newsDeskFraming;
  const labelKey = mode === "section" ? "section" : "news_desk";
  const topLabels = useMemo(() => {
    const totals = new Map();
    source.forEach((row) => totals.set(row[labelKey], (totals.get(row[labelKey]) || 0) + Number(row.articles || 0)));
    return Array.from(totals.entries()).sort((a, b) => b[1] - a[1]).slice(0, 10).map(([label]) => label);
  }, [source, labelKey]);
  const heatRows = source.filter((row) => topLabels.includes(row[labelKey]));

  return (
    <section id="metadata" className="section">
      <div className="section-heading">
        <p className="eyebrow">Metadata View</p>
        <h2>Where China Coverage Appears</h2>
      </div>
      <p className="section-note">
        This view groups articles by NYT section or news desk and shows the selected
        average framing score. It helps separate changes in language from changes in
        where China stories were published.
      </p>
      <div className="control-bar">
        <button className={mode === "section" ? "active" : ""} onClick={() => setMode("section")}>Section</button>
        <button className={mode === "news_desk" ? "active" : ""} onClick={() => setMode("news_desk")}>News Desk</button>
        <select value={metric} onChange={(event) => setMetric(event.target.value)}>
          <option value="rivalry_score">Rivalry score</option>
          <option value="economic_score">Economic score</option>
          <option value="security_score">Security score</option>
          <option value="technology_score">Technology score</option>
          <option value="net_framing_score">Net framing score</option>
        </select>
      </div>
      <div className="heatmap">
        <div className="heatmap-header">
          <span />
          {DECADES.map((decade) => <strong key={decade}>{decade}</strong>)}
        </div>
        {topLabels.map((label) => (
          <div className="heatmap-row" key={label}>
            <strong>{label}</strong>
            {DECADES.map((decade) => {
              const found = heatRows.find((row) => row[labelKey] === label && row.decade === decade);
              const value = Number(found?.[metric] || 0);
              const bucket = Math.min(4, Math.floor(value / 6));
              return <span key={decade} style={{ background: SECTION_COLORS[bucket] }}>{formatNumber(value, 1)}</span>;
            })}
          </div>
        ))}
      </div>
      <Card title="Reading The Heatmap">
        <p>
          The table shows the top metadata categories by article count. Darker cells
          indicate higher average scores for the selected metric within a decade.
        </p>
      </Card>
    </section>
  );
}

function KeywordsAndCloseReading({ keywords, articles }) {
  const [decade, setDecade] = useState("2020s");
  const [profile, setProfile] = useState("all");
  const [section, setSection] = useState("all");
  const keywordRows = keywords.filter((row) => row.decade === decade).slice(0, 20);
  const sections = Array.from(new Set(articles.map((row) => row.section).filter(Boolean))).sort();
  const articleRows = articles.filter((row) => {
    const articleDecade = `${Math.floor(Number(row.year) / 10) * 10}s`;
    return (
      articleDecade === decade &&
      (profile === "all" || row.profile === profile) &&
      (section === "all" || row.section === section)
    );
  });

  return (
    <section id="close-reading" className="section">
      <div className="section-heading">
        <p className="eyebrow">Keywords And Close Reading</p>
        <h2>From Pattern To Article</h2>
      </div>
      <div className="control-bar">
        <select value={decade} onChange={(event) => setDecade(event.target.value)}>
          {DECADES.map((item) => <option key={item}>{item}</option>)}
        </select>
        <select value={profile} onChange={(event) => setProfile(event.target.value)}>
          <option value="all">All frame types</option>
          <option value="high_economic_low_security">High economic, low security</option>
          <option value="high_security_low_economic">High security, low economic</option>
          <option value="high_economy_security_overlap">High economy + security overlap</option>
          <option value="high_technology_security_overlap">High technology + security overlap</option>
        </select>
        <select value={section} onChange={(event) => setSection(event.target.value)}>
          <option value="all">All sections</option>
          {sections.map((item) => <option key={item}>{item}</option>)}
        </select>
      </div>
      <div className="split">
        <div className="table-card">
          <h3>Top TF-IDF Keywords</h3>
          <table>
            <thead><tr><th>Rank</th><th>Keyword</th><th>Score</th></tr></thead>
            <tbody>
              {keywordRows.map((row) => (
                <tr key={`${row.decade}-${row.rank}-${row.keyword}`}>
                  <td>{row.rank}</td>
                  <td>{String(row.keyword).replaceAll("_", " ")}</td>
                  <td>{formatNumber(row.tfidf, 3)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="article-list">
          {articleRows.length === 0 && <p className="empty">No representative articles match these filters.</p>}
          {articleRows.map((article) => (
            <article key={`${article.profile}-${article.url}`} className="article-card">
              <span>{article.profile.replaceAll("_", " ")}</span>
              <h3>{article.headline}</h3>
              <p>{article.abstract || "No abstract available."}</p>
              <dl>
                <dt>Date</dt><dd>{String(article.date).slice(0, 10)}</dd>
                <dt>Section</dt><dd>{article.section || "Unknown"}</dd>
                <dt>Keywords</dt><dd>{article.keywords || "None listed"}</dd>
              </dl>
              {article.url && <a href={article.url} target="_blank" rel="noreferrer">Open NYT article</a>}
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

function MethodLimitations() {
  return (
    <section id="method" className="section method">
      <div className="section-heading">
        <p className="eyebrow">Method And Limitations</p>
        <h2>How The Evidence Was Made</h2>
      </div>
      <div className="method-grid">
        <Card title="Data Source">
          <p>
            The corpus comes from the New York Times Article Search API. The analysis uses
            headline, abstract, snippet, lead paragraph when available, and NYT keywords.
          </p>
        </Card>
        <Card title="Balanced Corpus">
          <p>
            The site uses the balanced quality-filtered corpus. The same number of clean
            articles is sampled from each decade to reduce article-count imbalance.
          </p>
        </Card>
        <Card title="Dictionary Scores">
          <p>
            Framing scores count transparent word dictionaries. They indicate textual
            framing patterns and should be paired with close reading.
          </p>
        </Card>
        <Card title="Embeddings">
          <p>
            Word vectors are built separately by decade from co-occurrence patterns.
            Similarity scores compare terms within each decade's vocabulary.
          </p>
        </Card>
        <Card title="Limits">
          <p>
            The project reflects NYT coverage, API retrieval limits, metadata availability,
            search bias, and a headline/abstract-centered corpus rather than full article text.
          </p>
        </Card>
      </div>
    </section>
  );
}

function ReferencesPage({ references }) {
  return (
    <main className="page">
      <section className="section">
        <div className="section-heading">
          <p className="eyebrow">References</p>
          <h2>Sources And Documentation</h2>
        </div>
        <div className="reference-list">
          {references.map((ref) => (
            <article className="article-card" key={ref.url}>
              <h3>{ref.title}</h3>
              <p>{ref.note}</p>
              <a href={ref.url} target="_blank" rel="noreferrer">{ref.url}</a>
            </article>
          ))}
        </div>
      </section>
    </main>
  );
}

function ExhibitPage({ data }) {
  return (
    <main>
      <Landing balanceSummary={data.balanceSummary} />
      <TimelineDashboard framingYear={data.framingYear} events={data.events} />
      <DecadeFramingComparison framingDecade={data.framingDecade} />
      <Securitization cooccurrenceYear={data.cooccurrenceYear} cooccurrenceDecade={data.cooccurrenceDecade} />
      <SemanticShift semanticPairs={data.semanticPairs} />
      <FrequencyAndThemes topWords={data.topWords} themeFraming={data.themeFraming} />
      <CooccurrenceNetwork network={data.wordNetwork} />
      <FramingByMetadata sectionFraming={data.sectionFraming} newsDeskFraming={data.newsDeskFraming} />
      <KeywordsAndCloseReading keywords={data.keywords} articles={data.articles} />
      <MethodLimitations />
    </main>
  );
}

export default function App() {
  const { data, error } = useProjectData();
  const [page, setPage] = useState("exhibit");

  if (error) {
    return <main className="status">Data loading error: {error}</main>;
  }

  if (!data) {
    return <main className="status">Loading project data...</main>;
  }

  return (
    <>
      <nav className="top-nav">
        <button className={page === "exhibit" ? "active" : ""} onClick={() => setPage("exhibit")}>Exhibit</button>
        <button className={page === "about" ? "active" : ""} onClick={() => setPage("about")}>About The Project</button>
        <button className={page === "references" ? "active" : ""} onClick={() => setPage("references")}>References</button>
        {page === "exhibit" && (
          <>
            <a href="#timeline">Timeline</a>
            <a href="#decade-framing">Decades</a>
            <a href="#securitization">Securitization</a>
            <a href="#semantic">Semantic Shift</a>
            <a href="#frequency">Frequency</a>
            <a href="#network">Network</a>
            <a href="#close-reading">Close Reading</a>
          </>
        )}
      </nav>
      {page === "exhibit" && <ExhibitPage data={data} />}
      {page === "about" && <AboutPage />}
      {page === "references" && <ReferencesPage references={data.references} />}
      <footer>
        <strong>NYT China Discourse Project</strong>
        <span>Static React exhibit using local JSON data from the balanced analysis corpus.</span>
      </footer>
    </>
  );
}
